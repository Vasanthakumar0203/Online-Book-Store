from tkinter import *
from subprocess import call
import sqlite3

def login():
    uname=username.get()
    pwd=password.get()
    if uname==''or pwd=='':
        message.set("Fill the Fields..")
    else:
        con=sqlite3.connect('user.db')
        cursor=con.execute('SELECT * FROM User where username="%s"and password="%s"'%(uname,pwd))
        if cursor.fetchone():
            message.set("Login success")

            def openfile():
                call(["Python", "bookstore.py"])

            openfile()

        else:
            message.set("Enter valid Username and Password")


def Loginform():
    global l_screen
    l_screen=Tk()
    l_screen.title("Online Book Store")
    l_screen.geometry("450x450")
    l_screen["bg"]="#1c2833"
    global message;
    global username
    global password
    username=StringVar()
    password=StringVar()
    message=StringVar()
    Label(l_screen,width="300",text="Login form ",bg="#0E6655",fg='white',font=("Arial",12,"bold")).pack()
    Label(l_screen,text="Username *",bg='#1C2833',fg='white',font=("Arial",12,'bold')).place(x=20,y=40)
    Entry(l_screen,textvariable=username,bg='#1C2833',fg='white',font=("Arial",12,"bold")).place(x=120,y=42)
    Label(l_screen,text='Password *',bg='#1C2833',fg='white',font=("Arial",12,"bold")).place(x=20,y=80)
    Entry(l_screen,textvariable=password,show="*",bg='#1C2833',fg='white',font=("Arial",12,"bold")).place(x=120,y=82)
    Label(l_screen,text="",textvariable=message,bg='#1C2833',fg='white',font=("Arial",12,"bold")).place(x=95,y=120)
    Button(l_screen,text="Login",width=10,height=1,command=login,bg='#0E6655',fg='white',font=("Arial",12,"bold")).place(x=125,y=170)

    btn_exit = Button(l_screen, text="Exit", fg="black", width=10,height=1, bg="#D3D3D3", border=0, font=("Arial",12,"bold"), command=exit)
    btn_exit.place(x=125, y=220)

    l_screen.mainloop()

Loginform()


from tkinter import *
from tkinter import ttk
import sqlite3
from subprocess import call

con=sqlite3.connect("user.db")

def register():
    name1=username.get()
    con1=contact.get()
    email1=mail.get()
    pwd1=password.get()
    if name1==''or con1==''or email1==''or pwd1=='':
        message.set("Fill the fields..")
    else:
        con.execute('INSERT INTO User(username,contact,mail,password)VALUES(?,?,?,?)',(name1,con1,email1,pwd1));
        con.commit()
        message.set("Stored successfully")
        con.close()
        def openfile():
            call(["Python", "ruser.py"])
        openfile()

def Registerform():
    global r_screen
    r_screen=Tk()
    r_screen.title("Registration form")
    r_screen.geometry("550x400")
    r_screen['bg']='#1C2833'
    global message;
    global username
    global contact
    global mail
    global password
    username=StringVar()
    contact=StringVar()
    mail=StringVar()
    password=StringVar()
    message=StringVar()
    Label(r_screen,width="400",text="Please enter the details..",bg='#0E6655',fg='white',font=("Arial",12,"bold")).pack()
    Label(r_screen, text="Name * ", bg="#1C2833",fg='white',font=("Arial",12,"bold")).place(x=20,y=40)
    Entry(r_screen, textvariable=username, bg='#1C2833' ,fg='white',font=('Arial',12,"bold")).place(x=100,y=42)

    Label(r_screen, text="Contact *", bg="#1C2833", fg='white', font=("Arial", 12, "bold")).place(x=20, y=80)
    Entry(r_screen, textvariable=contact, bg='#1C2833', fg='white', font=("Arial", 12, "bold")).place(x=100, y=82)

    Label(r_screen, text="Mail ", bg="#1C2833", fg='white', font=("Arial", 12, "bold")).place(x=20, y=120)
    Entry(r_screen, textvariable=mail, bg='#1C2833', fg='white', font=("Arial", 12, "bold")).place(x=100, y=122)

    Label(r_screen, text="Password", bg="#1C2833", fg='white', font=("Arial", 12, "bold")).place(x=20, y=160)
    Entry(r_screen, textvariable=password, bg='#1C2833', fg='white', font=("Arial", 12, "bold")).place(x=100, y=162)

    Label(r_screen,text="",textvariable=message,bg='#1C2833',fg='white',font=("Arial",12,"bold")).place(x=95,y=234)
    Button(r_screen,text="Register",width=10,height=1,bg="#0E6655",command=register,fg='white',font=("Arial",12,"bold")).place(x=155,y=280)

    btn_exit = Button(r_screen, text="Exit", fg="black", width=10, height=1, bg="#D3D3D3", border=0,font=("Arial", 12, "bold"), command=exit)
    btn_exit.place(x=155, y=320)

    r_screen.mainloop()
Registerform()
import sqlite3
con=sqlite3.connect("user.db")
print("Database created..")
con.execute("""
CREATE TABLE IF NOT EXISTS User
(
uid INTEGER PRIMARY KEY NOT NULL,
username TEXT NOT NULL,
contact TEXT,
mail TEXT,
password TEXT NOT NULL
)
""")
print("Table User created successfully")
#con.execute("INSERT INTO User(username,contact,mail,password)VALUES ('Abinaya','9876543210','abi@gmail.com','abi')");
#con.execute("DELETE FROM User where uid=4")
cursor=con.execute("SELECT * FROM User")
con.commit()
for r in cursor:
    print("{}\t{}\t{}\t{}\t{}".format(r[0],r[1],r[2],r[3],r[4]))

con.close()
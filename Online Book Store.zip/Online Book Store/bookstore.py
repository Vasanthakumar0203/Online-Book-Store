from tkinter import*
from subprocess import call

win=Tk()
win.title("Category")
win.geometry("1500x800")
win.config(bg="#CCCCFF")
def prog():
    call(["python", "prog.py"])

def fiction():
    call(["python", "fiction.py"])

def art():
    call(["python","art.py"])

def bio():
    call(["python","bio.py"])

def comic():
    call(["python","comic.py"])

img=PhotoImage(file="Sm.png")
Label(win,image=img,bg="white",width = 1460, height = 760).place(x=20,y=20)

frame=Frame(win,bg="#CCFFCC")
frame.pack(side=TOP,fill=Y)

title=Label(frame,text="Select the Category",font=("Calibri",18,"bold"),bg="#CCFFCC",fg="navy blue")
title.grid(row=0,columnspan=2,padx=10,pady=20,sticky="w")

btn_frame=Frame(frame,bg="#CCFFCC")
btn_frame.grid(row=4,column=0,columnspan=4,padx=10,pady=10)
btn1=Button(btn_frame,command=prog,text="PROGRAMMING",width=15,font=("Calibri",16,"bold"),fg="white",bg="#56AD8F",bd=0).grid(row=0,column=1)
btn2=Button(btn_frame,command=fiction,text="FICTION",width=15,font=("Calibri",16,"bold"),fg="white",bg="#808CDF",bd=0).grid(row=1,column=1,pady=20)
btn3=Button(btn_frame,command=art,text="ART",width=15,font=("Calibri",16,"bold"),fg="white",bg="#566D8F",bd=0).grid(row=2,column=1)
btn4=Button(btn_frame,command=bio,text="BIOGRAPHY",width=15,font=("Calibri",16,"bold"),fg="white",bg="#56CD8F",bd=0).grid(row=3,column=1,pady=20)
btn5=Button(btn_frame,command=comic,text="COMICS",width=15,font=("Calibri",16,"bold"),fg="white",bg="#686C8F",bd=0).grid(row=4,column=1)

btn_exit = Button(btn_frame, text="LOG OUT", fg="black", width=10, height=1, bg="#B8B3B3", border=0,font=("Calibri", 14, "bold"), command=exit)
btn_exit.grid(row=5,column=1,pady=10)

win.mainloop()

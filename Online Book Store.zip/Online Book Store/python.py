import webbrowser
from tkinter import *
import subprocess

win=Tk()
win.title("Python")
win.geometry("1500x800")
win.config(bg="white")
def bn1():
   subprocess.Popen(['python1.pdf'], shell=True)

def bn2():
   subprocess.Popen(['python2.pdf'],shell=True)

def bn3():
   subprocess.Popen(['python3.pdf'],shell=True)

def bn4():
   subprocess.Popen(['python4.pdf'], shell=True)

def bn5():
   subprocess.Popen(['python5.pdf'], shell=True)

def bn6():
   subprocess.Popen(['python6.pdf'], shell=True)


frame=Frame(win,bg="white")
frame.pack(side=TOP,fill=X)

Label(frame,text="//To read the books:\n\nClick on Author name",bg="white",fg="black",font=("times",13,"bold")).place(x=1200,y=80)
Label(frame,text="//Scan the QR Code to read and\n\nDownload the books",bg="white",fg="black",font=("times",13,"bold")).place(x=1200,y=250)

def cal():
   webbrowser.open_new("https://www.google.com/")

Label(frame,text="Search other books in Online",bg="white",fg="black",font=("times",13,"bold")).place(x=1200,y=400)
Button(frame,text="Google", command=cal,bg="skyblue",width=15,height=2).place(x=1200,y=430)

title=Label(frame,text="Python Programming",font=("Calibri",18,"bold"),bg="#535c68",fg="white")
title.grid(row=1,columnspan=4,padx=10,pady=10)

labname=Label(frame,text="Introduction to Python",bg="white",fg="black",font=("times",16,"bold"))
labname.grid(row=2,column=0,pady=50)
btn1=Button(frame,command=bn1,text="E.Balagurusamy",width=15,font=("Calibri",16,"bold"),fg="white",bg="#16a085").grid(row=3,column=0)

img1=PhotoImage(file="p1.png")
Label(win,image=img1,bg="white",width=200,height=200).place(x=350,y=40)

labname=Label(frame,text="Head-First python",bg="white",fg="black",font=("times",16,"bold"))
labname.grid(row=4,column=0,pady=50)
btn2=Button(frame,command=bn2,text="Paul Barry",width=15,font=("Calibri",16,"bold"),fg="white",bg="#2980b9").grid(row=5,column=0)

img2=PhotoImage(file="p2.png")
Label(win,image=img2,bg="white",width=200,height=200).place(x=350,y=240)

labname=Label(frame,text="Python for everybody",bg="white",fg="black",font=("times",16,"bold"))
labname.grid(row=6,column=0,pady=60)
btn3=Button(frame,command=bn3,text="R Severance",width=15,font=("Calibri",16,"bold"),fg="white",bg="#108076").grid(row=7,column=0)

img3=PhotoImage(file="p3.png")
Label(win,image=img3,bg="white",width=200,height=200).place(x=350,y=440)

labname=Label(frame,text="Learning Python",bg="white",fg="black",font=("times",16,"bold"))
labname.place(x=640,y=100)
btn4=Button(frame,command=bn4,text="Mark Lutz",width=15,font=("Calibri",16,"bold"),fg="white",bg="navyblue").place(x=640,y=180)

img4=PhotoImage(file="p4.png")
Label(win,image=img4,bg="white",width=200,height=200).place(x=950,y=40)

labname=Label(frame,text="Black Hat Python",bg="white",fg="black",font=("times",16,"bold"))
labname.place(x=640,y=280)
btn5=Button(frame,command=bn5,text="Justin Seitz",width=15,font=("Calibri",16,"bold"),fg="white",bg="#298089").place(x=640,y=360)

img5=PhotoImage(file="p5.png")
Label(win,image=img5,bg="white",width=200,height=200).place(x=950,y=240)

labname=Label(frame,text="Python Data Analytics",bg="white",fg="black",font=("times",16,"bold"))
labname.place(x=640,y=460)
btn6=Button(frame,command=bn6,text="Fabio Nelli",width=15,font=("Calibri",16,"bold"),fg="white",bg="#16CB85").place(x=640,y=550)

img6=PhotoImage(file="p6.png")
Label(win,image=img6,bg="white",width=200,height=200).place(x=950,y=440)

btn7=Button(frame,command=exit,text="Back",width=15,font=("Calibri",16,"bold"),fg="white",bg="#c0392b").place(x=1200,y=560)

win.mainloop()

from tkinter import*
from subprocess import call

win=Tk()
win.title("Programming")
win.geometry("800x800")
win.config(bg="#535c68")
def python():
    call(["python", "python.py"])

def java():
    call(["python", "java.py"])

def c():
    call(["python", "c.py"])

frame=Frame(win,bg="white")
frame.pack(side=TOP,fill=Y)

title=Label(frame,text="Select the Language",font=("Calibri",18,"bold"),bg="#535c68",fg="white")
title.grid(row=0,columnspan=2,padx=10,pady=20,sticky="w")

btn_frame=Frame(frame)
btn_frame.grid(row=8,column=0,columnspan=4,padx=10,pady=10,sticky="w")
btn1=Button(btn_frame,command=python,text="PYTHON",width=15,font=("Calibri",16,"bold"),fg="white",bg="#16a085",bd=0).grid(row=1,column=0,pady=10)
btn2=Button(btn_frame,command=java,text="JAVA",width=15,font=("Calibri",16,"bold"),fg="white",bg="#2980b9",bd=0).grid(row=3,column=0,pady=10)
btn3=Button(btn_frame,command=c,text="C++ & C",width=15,font=("Calibri",16,"bold"),fg="white",bg="#c0392b",bd=0).grid(row=5,column=0,padx=20,pady=10)

btn4=Button(btn_frame,command=exit,text="Back",width=15,font=("Calibri",16,"bold"),fg="white",bg="#c0B92b",bd=0).grid(row=7,column=2,padx=10,pady=10)
win.mainloop()
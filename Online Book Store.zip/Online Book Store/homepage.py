from tkinter import*
from subprocess import call

win=Tk()
win.title("Welcome to Book store")
win.geometry("1500x800")
win.config(bg="#CCCCFF")
def admin():
    call(["python", "admin.py"])

def user():
    call(["python", "ruser.py"])

def new():
    def openfile():
        call(["python", "user.py"])
    openfile()

img=PhotoImage(file="books.png")
Label(win,image=img,width=1460,height=760).place(x=20,y=20)

frame=Frame(win,bg="#CCFFFF",width=400,height=400)
frame.place(x=600,y=200)

title=Label(frame,text="Select Your Role",font=("Calibri",18,"bold"),bg="#CCFFFF",fg="navy blue")
title.grid(row=0,columnspan=2,padx=20,pady=20)

btn_frame=Frame(frame,bg="#CCFFFF")
btn_frame.grid(row=4,column=0,columnspan=8,padx=10,pady=10,sticky="w")
btn1=Button(btn_frame,command=admin,text="ADMIN",width=15,font=("Calibri",16,"bold"),fg="white",bg="navy blue",bd=0).grid(row=0,column=1)
btn2=Button(btn_frame,command=user,text="USER",width=15,font=("Calibri",16,"bold"),fg="white",bg="green",bd=0).grid(row=1,column=1,pady=20)
btn3=Button(btn_frame,command=new,text="NEW USER",width=15,font=("Calibri",16,"bold"),fg="white",bg="navy blue",bd=0).grid(row=2,column=1)

win.mainloop()

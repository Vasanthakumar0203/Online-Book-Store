import sqlite3

class Database:

    def __init__(self, db):
        self.conn = sqlite3.connect(db)
        self.cur = self.conn.cursor()
        self.cur.execute(
            "CREATE TABLE IF NOT EXISTS User (uid INTEGER PRIMARY KEY, username text, contact text, mail text, password text) ")
        self.conn.commit()

    def insert(self, username, contact,mail, password):
        self.cur.execute("INSERT INTO User VALUES(?,?,?,?)", (username, contact,mail, password))
        self.conn.commit()

    def view(self):
        self.cur.execute("SELECT * FROM User")
        rows = self.cur.fetchall()
        return rows

    def search(self, username="", uid=""):
        self.cur.execute("SELECT * FROM User WHERE username=? OR uid=? ",
                         (username, uid))
        rows = self.cur.fetchall()
        return rows

    def delete(self, uid):
        self.cur.execute("DELETE FROM User WHERE uid=?", (uid,))
        self.conn.commit()

    def update(self, uid, username, contact,mail, password):
        self.cur.execute("UPDATE User SET username=?, contact=?,mail=?, password=? WHERE uid=?",
                         (username, contact, mail,password, uid))
        self.conn.commit()

    def __del__(self):
        self.conn.close()

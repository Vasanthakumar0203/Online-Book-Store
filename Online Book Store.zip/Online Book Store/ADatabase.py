import sqlite3
con=sqlite3.connect("admin.db")
print("Database created..")
con.execute("""
        CREATE TABLE IF NOT EXISTS Admin
        (
        aid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        username TEXT NOT NULL,
        password TEXT NOT NULL
         )
        """)
print("Table Admin created successfully")
#con.execute("INSERT INTO Admin(username,password)VALUES ('admin','admin')");

print("Records inserted..")
cursor=con.execute("SELECT * FROM Admin")
for r in cursor:
    print("{}\t{}\t{}".format(r[0],r[1],r[2]))
con.commit()
con.close()


from tkinter import *
from backend import Database

database= Database("user.db")

window = Tk()
window.geometry("700x500")
window.config(background='LightBlue')


def get_selected_row(event):
    try:
        global select_tup
        index=list1.curselection()[0]
        select_tup = list1.get(index)
        e1.delete(0,END)
        e1.insert(END, select_tup[1])
        e2.delete(0,END)
        e2.insert(END, select_tup[2])
        e3.delete(0,END)
        e3.insert(END, select_tup[3])
        e4.delete(0,END)
        e4.insert(END, select_tup[4])
        #e5.delete(0,END)
        #e5.insert(END,select_tup[5])
    except IndexError:
        pass


def view_command():
    list1.delete(0,END)
    for row in database.view():
        list1.insert(END, row)

def search_command():
    list1.delete(0,END)
    for row in database.search(username_text.get()):
        list1.insert(END,row)

"""def add_user():
    database.insert(username_text.get(),contact_text.get(),mail_text(),password_text())
    list1.delete(0,END)
    list1.insert(END,(username_text.get(),contact_text(),mail_text(),password_text.get()))"""

def delete_user():
    database.delete(select_tup[0])

def update_user():
    database.update(select_tup[0],username_text.get(),contact_text.get(),mail_text.get(),password_text.get())

window.wm_title("User Details")


l1 = Label(window, text="Username")
l1.grid(row=0,column=0,pady=10)

l2 = Label(window, text="Contact")
l2.grid(row=0,column=2,pady=10)

l3 = Label(window, text="Mail")
l3.grid(row=1,column=0,pady=10)

l4=Label(window,text="Password")
l4.grid(row=1,column=2,pady=10)

"""l5=Label(window,text="UID")
l5.grid(row=2,column=0)"""

username_text = StringVar()
e1 = Entry(window, textvariable= username_text)
e1.grid(row=0, column=1,pady=10)

contact_text = StringVar()
e2 = Entry(window, textvariable=contact_text)
e2.grid(row=0, column=3,pady=10)

mail_text = StringVar()
e3 = Entry(window, textvariable= mail_text)
e3.grid(row=1, column=1,pady=10)

password_text=StringVar()
e4=Entry(window,textvariable=password_text)
e4.grid(row=1,column=3,pady=10)

"""uid_text=StringVar()
e5=Entry(window,textvariable=uid_text)
e5.grid(row=2,column=1)"""

list1 = Listbox(window, height=7, width=45)
list1.grid(row=3, column =0, rowspan=6, columnspan=2,padx=20)

list1.bind("<<ListboxSelect>>", get_selected_row)

sb1 =Scrollbar(window)
sb1.grid(row=3, column=2 ,rowspan = 6)

list1.configure(yscrollcommand=sb1.set)
sb1.configure(command=list1.yview)

b1 =Button(window, text= "View All", width=12, command=view_command)
b1.grid(row=2, column=3,pady=10)

b2 =Button(window, text= "Search User", width=12, command=search_command)
b2.grid(row=3, column=3,pady=10)

#b3 =Button(window, text= "Add User", width=12, command=add_user)
#b3.grid(row=4, column=3)

b4 =Button(window, text= "Update", width=12, command=update_user)
b4.grid(row=5, column=3,pady=10)

b5 =Button(window, text= "Delete", width=12, command=delete_user)
b5.grid(row=6, column=3,pady=10)

b6 =Button(window, text= "Close", width=12, command=window.destroy)
b6.grid(row=7, column=3,pady=10)


window.mainloop()